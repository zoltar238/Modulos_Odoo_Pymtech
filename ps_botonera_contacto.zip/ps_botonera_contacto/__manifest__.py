# -*- coding: utf-8 -*-
{
    'name': "PS order botonera modificado",

    'summary': "Módulo que modifica el orden de la botonera",

    'author': "Pymtech Solutions",

    'version': '0.1',

    'depends': ['base','helpdesk_mgmt','stock','sale_management'],

    'data': [
        'views/partner.xml'
    ],
}

