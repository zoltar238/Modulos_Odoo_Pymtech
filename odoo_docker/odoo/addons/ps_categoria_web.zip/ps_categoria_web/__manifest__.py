# -*- coding: utf-8 -*-
{
    'name': "PS Categorias de Productos Coincidentes con Categorias Web",

    'summary': "Hace que las categorias de productos coincidan con las categorias web",

    'description': """
        Este modulo hace que las categorias de productos coincidan con las categorias web
    """,

    'author': "Pymtech Solutions",

    'category': 'Uncategorized',

    'version': '0.1',

    'depends': ['base', 'product', 'web', 'website_sale'],

    'data': [
        'data/ir_cron_data.xml'
    ],
}
